---
name: "\U0001F947 Challenge Program"
about: Challenge Program issues
labels: challenge-program-2
---

## Description

## Score

* score number

## Mentor(s)

* [@xxxx](github url)

Contact the mentors: **#tidb-challenge-program** channel in [TiDB Community](https://join.slack.com/t/tidbcommunity/shared_invite/enQtNzc0MzI4ODExMDc4LWYwYmIzMjZkYzJiNDUxMmZlN2FiMGJkZjAyMzQ5NGU0NGY0NzI3NTYwMjAyNGQ1N2I2ZjAxNzc1OGUwYWM0NzE)  Slack Workspace

## Recommended Skills

* skills 1
* skills 1

## Learning Materials

* Chinese: [TiDB 精选技术讲解文章](https://github.com/pingcap/presentations/blob/master/hackathon-2019/reference-document-of-hackathon-2019.md)
* English: [Awesome-Database-Learning](https://github.com/pingcap/awesome-database-learning)
